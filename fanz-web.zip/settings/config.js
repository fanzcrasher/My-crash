module.exports = {
 GITHUB_TOKEN: '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', // Ganti dengan token GitHub Anda
 REPO_OWNER: 'didzxysaca', // Ganti dengan username GitHub pemilik repo
  REPO_NAME: 'miawmiaw', // Ganti dengan nama repo
  FILE_PATH: 'db_apibug.json', // Path file dalam repo
};