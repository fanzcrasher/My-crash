global.creator = "@dxychi"
global.token = "8098196909:AAF0vtnuuFFoT6aLqaJTPmxVn-Zlt9cZZEA"
global.chatid = "6654208907"
global.watermark = "© Dxyvxz"
